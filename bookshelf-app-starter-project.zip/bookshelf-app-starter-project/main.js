// Kunci untuk localStorage
const STORAGE_KEY = 'BOOKSHELF_APPS';
const RENDER_EVENT = 'render-books';

// Inisialisasi array books
let books = [];

// Fungsi untuk mengecek dukungan localStorage
function isStorageExist() {
  if (typeof (Storage) === undefined) {
    alert('Browser tidak mendukung localStorage');
    return false;
  }
  return true;
}

// Fungsi untuk menyimpan data ke localStorage
function saveData() {
  if (isStorageExist()) {
    const parsed = JSON.stringify(books);
    localStorage.setItem(STORAGE_KEY, parsed);
  }
}

// Fungsi untuk memuat data dari localStorage
function loadDataFromStorage() {
  const serializedData = localStorage.getItem(STORAGE_KEY);
  let data = JSON.parse(serializedData);
  
  if (data !== null) {
    books = data;
  }

  document.dispatchEvent(new Event(RENDER_EVENT));
}

// Fungsi untuk menghasilkan ID unik
function generateId() {
  return +new Date();
}

// Fungsi untuk membuat objek buku baru
function createBookObject(title, author, year, isComplete) {
  return {
    id: generateId(),
    title,
    author,
    year: parseInt(year),
    isComplete
  };
}

// Fungsi untuk menambah buku baru
function addBook() {
  const titleInput = document.getElementById('bookFormTitle');
  const authorInput = document.getElementById('bookFormAuthor');
  const yearInput = document.getElementById('bookFormYear');
  const isCompleteInput = document.getElementById('bookFormIsComplete');

  const book = createBookObject(
    titleInput.value,
    authorInput.value,
    yearInput.value,
    isCompleteInput.checked
  );

  books.push(book);
  document.dispatchEvent(new Event(RENDER_EVENT));
  saveData();
  
  // Reset form
  titleInput.value = '';
  authorInput.value = '';
  yearInput.value = '';
  isCompleteInput.checked = false;
}

// Fungsi untuk menemukan buku berdasarkan ID
function findBook(bookId) {
  return books.find(book => book.id === bookId);
}

// Fungsi untuk menemukan index buku
function findBookIndex(bookId) {
  return books.findIndex(book => book.id === bookId);
}

// Fungsi untuk memindahkan buku antar rak
function moveBook(bookId) {
  const book = findBook(bookId);
  if (book) {
    book.isComplete = !book.isComplete;
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
  }
}

// Fungsi untuk menghapus buku
function removeBook(bookId) {
  const bookIndex = findBookIndex(bookId);
  if (bookIndex !== -1) {
    books.splice(bookIndex, 1);
    document.dispatchEvent(new Event(RENDER_EVENT));
    saveData();
  }
}

// Fungsi untuk mencari buku
function searchBooks(keyword) {
  const filteredBooks = books.filter(book => 
    book.title.toLowerCase().includes(keyword.toLowerCase())
  );
  renderFilteredBooks(filteredBooks);
}

// Fungsi untuk merender buku yang difilter
function renderFilteredBooks(filteredBooks) {
  const incompleteBookList = document.getElementById('incompleteBookList');
  const completeBookList = document.getElementById('completeBookList');
  
  // Bersihkan konten sebelumnya
  incompleteBookList.innerHTML = '';
  completeBookList.innerHTML = '';

  // Render buku yang difilter
  for (const book of filteredBooks) {
    const bookElement = createBookElement(book);
    if (book.isComplete) {
      completeBookList.append(bookElement);
    } else {
      incompleteBookList.append(bookElement);
    }
  }
}

// Fungsi untuk membuat elemen buku
function createBookElement(book) {
  const bookItem = document.createElement('div');
  bookItem.setAttribute('data-bookid', book.id);
  bookItem.setAttribute('data-testid', 'bookItem');

  const title = document.createElement('h3');
  title.setAttribute('data-testid', 'bookItemTitle');
  title.innerText = book.title;

  const author = document.createElement('p');
  author.setAttribute('data-testid', 'bookItemAuthor');
  author.innerText = `Penulis: ${book.author}`;

  const year = document.createElement('p');
  year.setAttribute('data-testid', 'bookItemYear');
  year.innerText = `Tahun: ${book.year}`;

  const actionDiv = document.createElement('div');
  
  const toggleButton = document.createElement('button');
  toggleButton.setAttribute('data-testid', 'bookItemIsCompleteButton');
  toggleButton.innerText = book.isComplete ? 'Belum selesai dibaca' : 'Selesai dibaca';
  toggleButton.onclick = () => moveBook(book.id);

  const deleteButton = document.createElement('button');
  deleteButton.setAttribute('data-testid', 'bookItemDeleteButton');
  deleteButton.innerText = 'Hapus Buku';
  deleteButton.onclick = () => {
    if (confirm('Apakah Anda yakin ingin menghapus buku ini?')) {
      removeBook(book.id);
    }
  };

  const editButton = document.createElement('button');
  editButton.setAttribute('data-testid', 'bookItemEditButton');
  editButton.innerText = 'Edit Buku';
  editButton.onclick = () => {
    // Implementasi edit buku bisa ditambahkan di sini
    alert('Fitur edit akan segera hadir!');
  };

  actionDiv.append(toggleButton, deleteButton, editButton);
  bookItem.append(title, author, year, actionDiv);

  return bookItem;
}

// Event listener saat DOM dimuat
document.addEventListener('DOMContentLoaded', function () {
  const bookForm = document.getElementById('bookForm');
  const searchForm = document.getElementById('searchBook');

  bookForm.addEventListener('submit', function (e) {
    e.preventDefault();
    addBook();
  });

  searchForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const keyword = document.getElementById('searchBookTitle').value;
    searchBooks(keyword);
  });

  if (isStorageExist()) {
    loadDataFromStorage();
  }
});

// Event listener untuk render buku
document.addEventListener(RENDER_EVENT, function () {
  const incompleteBookList = document.getElementById('incompleteBookList');
  const completeBookList = document.getElementById('completeBookList');

  // Bersihkan konten sebelumnya
  incompleteBookList.innerHTML = '';
  completeBookList.innerHTML = '';

  // Render semua buku
  for (const book of books) {
    const bookElement = createBookElement(book);
    if (book.isComplete) {
      completeBookList.append(bookElement);
    } else {
      incompleteBookList.append(bookElement);
    }
  }
});